package com.Marks;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        Marks m = new Marks();
			m.display_Marks();
			m.get_grade();
		}
	}



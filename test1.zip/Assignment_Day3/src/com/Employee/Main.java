package com.Employee;
import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Employee e1 = new Employee();
		e1.showDetails();
		e1.annualSalary();
		e1.taxAmount();
		Employee e2 = new Employee();
		e2.showDetails();
		e2.annualSalary();
		e2.taxAmount();
	    Employee e3 = new Employee();
	    e3.showDetails();
	    e3.annualSalary();
	    e3.taxAmount();
		Employee e4 = new Employee();
		e4.showDetails();
		e4.annualSalary();
		e4.taxAmount();
		

	}

}
